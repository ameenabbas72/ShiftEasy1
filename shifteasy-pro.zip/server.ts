import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Mock Database
  const bookings: any[] = [];

  // API Logic / Pricing Engine
  app.post("/api/calculate-fare", (req, res) => {
    const { distance, vehicleType } = req.body;
    const pricing: Record<string, { base: number; perKm: number }> = {
      small: { base: 500, perKm: 15 },
      medium: { base: 1500, perKm: 30 },
      large: { base: 3500, perKm: 55 },
    };

    const config = pricing[vehicleType];
    if (!config) return res.status(400).json({ error: "Invalid vehicle type" });

    const totalFare = config.base + distance * config.perKm;
    res.json({ totalFare });
  });

  app.post("/api/bookings", (req, res) => {
    const { pickup, drop, distance, vehicleType, totalFare } = req.body;
    const newBooking = {
      bookingID: `SH-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      pickup,
      drop,
      distance,
      vehicleType,
      totalFare,
      timestamp: new Date().toISOString(),
      status: "searching",
    };
    bookings.push(newBooking);
    res.status(201).json(newBooking);
  });

  app.get("/api/bookings", (req, res) => {
    res.json(bookings);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ShiftEasy Server running on http://localhost:${PORT}`);
  });
}

startServer();
