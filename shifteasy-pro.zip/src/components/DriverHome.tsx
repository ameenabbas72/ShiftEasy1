import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BarChart3, Wallet, Star, MapPin, 
  Navigation2, CheckCircle2, XCircle, 
  Clock, Package, User, ChevronRight,
  Power, ShieldCheck, Phone, Zap
} from "lucide-react";
import { cn } from "../lib/utils";
import { Booking } from "../types";

interface DriverHomeProps {
  onStatusToggle: (online: boolean) => void;
  isOnline: boolean;
  activeBooking?: Booking;
  onAcceptOrder: (id: string) => void;
  onRejectOrder: (id: string) => void;
  onUpdateStatus: (status: Booking["status"]) => void;
}

const STATS = [
  { label: "Trips Today", value: "12", icon: BarChart3, color: "text-blue-600" },
  { label: "Earnings", value: "₹2,450", icon: Wallet, color: "text-emerald-600" },
  { label: "Rating", value: "4.9", icon: Star, color: "text-orange-500" },
];

export default function DriverHome({ 
  onStatusToggle, 
  isOnline, 
  activeBooking, 
  onAcceptOrder,
  onRejectOrder,
  onUpdateStatus
}: DriverHomeProps) {
  const [mockOrders, setMockOrders] = useState<Partial<Booking>[]>([]);

  // Simulation: Incoming order if online
  useEffect(() => {
    if (isOnline && !activeBooking) {
      const timer = setTimeout(() => {
        setMockOrders([{
          bookingID: "ORD-102",
          pickup: { address: "Indiranagar, Metro Station", lat: 0, lng: 0 },
          drop: { address: "HSR Layout, Sector 2", lat: 0, lng: 0 },
          totalFare: 450,
          distance: 8.5,
          vehicleType: "tata_ace"
        }]);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isOnline, activeBooking]);

  return (
    <div className="w-full max-w-2xl mx-auto pb-24 bg-slate-50 min-h-screen lg:rounded-[32px] lg:shadow-2xl overflow-hidden relative">
      {/* Header */}
      <div className="bg-white p-6 border-b border-slate-100 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-400 overflow-hidden">
            <User className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-black text-slate-900 leading-none">Partner Dashboard</h1>
            <div className="flex items-center gap-1.5 mt-1">
              <div className={cn("w-1.5 h-1.5 rounded-full", isOnline ? "bg-emerald-500" : "bg-slate-300")} />
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{isOnline ? "Active & Online" : "Offline Mode"}</span>
            </div>
          </div>
        </div>
        
        <button 
          onClick={() => onStatusToggle(!isOnline)}
          className={cn(
            "w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-lg active:scale-95",
            isOnline ? "bg-emerald-500 text-white shadow-emerald-500/20" : "bg-slate-200 text-slate-400 shadow-slate-200/20"
          )}
        >
          <Power className="w-6 h-6" />
        </button>
      </div>

      <div className="p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-3">
          {STATS.map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.label} className="bg-white p-4 rounded-[28px] border border-slate-100 shadow-sm">
                <Icon className={cn("w-4 h-4 mb-3", s.color)} />
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter block mb-0.5">{s.label}</span>
                <span className="text-lg font-black text-slate-900 tracking-tight">{s.value}</span>
              </div>
            );
          })}
        </div>

        {/* Status / Active Order */}
        <AnimatePresence mode="wait">
          {!isOnline ? (
            <motion.div 
              key="offline"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-900 rounded-[32px] p-8 text-center"
            >
              <div className="w-16 h-16 bg-white/10 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <Power className="w-8 h-8 text-white/40" />
              </div>
              <h2 className="text-xl font-black text-white mb-2">You are Offline</h2>
              <p className="text-slate-400 text-xs font-medium px-8 mb-8">Go online to start receiving orders in your area.</p>
              <button 
                onClick={() => onStatusToggle(true)}
                className="px-8 py-4 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-blue-700 shadow-xl shadow-blue-600/30 transition-all"
              >
                Go Online Now
              </button>
            </motion.div>
          ) : activeBooking ? (
            <motion.div 
              key="active"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-[32px] overflow-hidden shadow-2xl border border-blue-100"
            >
              <div className="bg-blue-600 p-6 text-white">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-black bg-white/20 px-2.5 py-1 rounded-full uppercase tracking-widest">Active Order</span>
                  <span className="text-lg font-black tracking-tight">₹{activeBooking.totalFare}</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                    <Navigation2 className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-blue-100">Booking ID</p>
                    <p className="text-sm font-black">{activeBooking.bookingID}</p>
                  </div>
                </div>
              </div>

              <div className="p-6 space-y-6">
                <div className="space-y-4 relative">
                  <div className="absolute left-2.5 top-3 w-0.5 h-[calc(100%-24px)] bg-slate-100" />
                  
                  <div className="flex gap-4">
                    <div className="w-5 h-5 rounded-full border-4 border-blue-500 bg-white z-10 shrink-0 mt-1" />
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Pickup From</p>
                      <p className="text-xs font-bold text-slate-700">{activeBooking.pickup.address}</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-5 h-5 rounded-full border-4 border-red-500 bg-white z-10 shrink-0 mt-1" />
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase mb-1">Drop To</p>
                      <p className="text-xs font-bold text-slate-700">{activeBooking.drop.address}</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  {activeBooking.status === "confirmed" && (
                    <button 
                      onClick={() => onUpdateStatus("picked_up")}
                      className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
                    >
                      Reached Pickup
                    </button>
                  )}
                  {activeBooking.status === "picked_up" && (
                    <button 
                      onClick={() => onUpdateStatus("on_route")}
                      className="flex-1 py-4 bg-orange-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-orange-500/20 active:scale-95 transition-all"
                    >
                      Start Delivery
                    </button>
                  )}
                  {activeBooking.status === "on_route" && (
                    <button 
                      onClick={() => onUpdateStatus("delivered")}
                      className="flex-1 py-4 bg-emerald-500 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
                    >
                      Complete Delivery
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          ) : mockOrders.length > 0 ? (
            <motion.div 
              key="pending"
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              className="bg-white rounded-[32px] p-6 shadow-2xl border-4 border-blue-500 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-4">
                <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center border-4 border-white shadow-sm">
                  <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
                </div>
              </div>

              <div className="flex items-center gap-2 mb-6">
                <Zap className="w-5 h-5 text-blue-600" />
                <h2 className="text-lg font-black text-slate-900">New Order Available!</h2>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-8">
                <div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Potential Earnings</span>
                  <p className="text-2xl font-black text-emerald-600">₹{mockOrders[0].totalFare}</p>
                </div>
                <div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Distance</span>
                  <p className="text-2xl font-black text-slate-900">{mockOrders[0].distance} KM</p>
                </div>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex gap-3">
                  <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                  <p className="text-xs font-bold text-slate-600 truncate">{mockOrders[0].pickup?.address}</p>
                </div>
                <div className="flex gap-3">
                  <Navigation2 className="w-4 h-4 text-slate-400 shrink-0" />
                  <p className="text-xs font-bold text-slate-600 truncate">{mockOrders[0].drop?.address}</p>
                </div>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={() => onRejectOrder(mockOrders[0].bookingID!)}
                  className="flex-1 py-4 bg-slate-100 text-slate-500 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-200 transition-all"
                >
                  Reject
                </button>
                <button 
                  onClick={() => onAcceptOrder(mockOrders[0].bookingID!)}
                  className="flex-2 py-4 bg-blue-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-700 shadow-xl shadow-blue-600/30 active:scale-95 transition-all"
                >
                  Accept Order
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.div 
               key="searching"
               initial={{ opacity: 0 }}
               animate={{ opacity: 1 }}
               className="bg-white rounded-[32px] p-12 text-center border-2 border-dashed border-slate-200"
            >
              <div className="relative w-24 h-24 mx-auto mb-6">
                <div className="absolute inset-0 border-4 border-blue-500 border-t-transparent rounded-full animate-spin opacity-20" />
                <div className="absolute inset-4 border-4 border-blue-500 border-b-transparent rounded-full animate-[spin_1.5s_linear_infinite]" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Radar className="w-8 h-8 text-blue-600" />
                </div>
              </div>
              <h2 className="text-xl font-black text-slate-900 mb-2">Searching Orders</h2>
              <p className="text-slate-400 text-xs font-medium">Staying in high-demand areas <br />increases order frequency.</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* History Preview */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">Recent Activity</h3>
            <button className="text-[10px] font-black text-blue-600 uppercase">View History</button>
          </div>
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="bg-white p-4 rounded-3xl border border-slate-100 flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-50 rounded-xl flex items-center justify-center text-emerald-500">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-black text-slate-800">Delivered Successfully</p>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">2h ago • Cash Payment</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-black text-emerald-600">+₹320</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Bottom Nav Bar - Driver */}
      <div className="fixed bottom-0 left-0 right-0 p-4 lg:p-8 pointer-events-none flex justify-center z-50">
        <div className="bg-slate-900 rounded-[32px] p-2 flex items-center gap-1 shadow-2xl pointer-events-auto border border-white/10 max-w-sm w-full transition-all">
          <button className="flex-1 py-3 bg-white/10 rounded-2xl flex flex-col items-center gap-1 text-white border border-white/5">
            <BarChart3 className="w-4 h-4" />
            <span className="text-[8px] font-black uppercase tracking-widest">Dashboard</span>
          </button>
          <button className="flex-1 py-3 text-white/40 hover:bg-white/5 rounded-2xl flex flex-col items-center gap-1 transition-all">
            <Wallet className="w-4 h-4" />
            <span className="text-[8px] font-black uppercase tracking-widest">Wallet</span>
          </button>
          <button className="flex-1 py-3 text-white/40 hover:bg-white/5 rounded-2xl flex flex-col items-center gap-1 transition-all">
            <ShieldCheck className="w-4 h-4" />
            <span className="text-[8px] font-black uppercase tracking-widest">KYC</span>
          </button>
          <button className="flex-1 py-3 text-white/40 hover:bg-white/5 rounded-2xl flex flex-col items-center gap-1 transition-all">
            <User className="w-4 h-4" />
            <span className="text-[8px] font-black uppercase tracking-widest">Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
}

function Radar({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m19.07 4.93-1.41 1.41" /><path d="M22 12h-2" /><path d="m19.07 19.07-1.41-1.41" /><path d="M12 22v-2" /><path d="m4.93 19.07 1.41-1.41" /><path d="M2 12h2" /><path d="m4.93 4.93 1.41 1.41" /><path d="M12 2v2" /><circle cx="12" cy="12" r="8" />
    </svg>
  )
}
