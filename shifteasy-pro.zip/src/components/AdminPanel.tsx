import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  Users, Truck, Package, Shield, 
  TrendingUp, AlertCircle, Search,
  Filter, Download, MoreVertical,
  Activity, CheckCircle2, Clock
} from "lucide-react";
import { cn } from "../lib/utils";
import { collection, query, getDocs, limit } from "firebase/firestore";
import { db } from "../lib/firebase";
import { Booking } from "../types";
import { handleFirestoreError, OperationType } from "../lib/firestore-errors";

export default function AdminPanel() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const q = query(collection(db, "bookings"), limit(10));
        const snap = await getDocs(q);
        setBookings(snap.docs.map(doc => doc.data() as Booking));
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, "bookings");
      } finally {
        setLoading(false);
      }
    };
    fetchBookings();
  }, []);

  return (
    <div className="w-full max-w-6xl mx-auto p-6 md:p-12 bg-slate-50 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">Admin Terminal</h1>
          <p className="text-slate-500 font-medium mt-1">Global logistics & partner management</p>
        </div>
        <div className="flex gap-3">
          <button className="px-6 py-3 bg-white border border-slate-200 rounded-2xl font-black text-[10px] uppercase tracking-widest text-slate-600 hover:bg-slate-50 transition-all flex items-center gap-2">
            <Download className="w-4 h-4" /> Export Data
          </button>
          <button className="px-6 py-3 bg-blue-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-blue-600/20 hover:bg-blue-700 transition-all">
            Sys Health: OK
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
        {[
          { label: "Active Bookings", value: "42", icon: Package, color: "text-blue-600", trend: "+12%" },
          { label: "Online Drivers", value: "156", icon: Truck, color: "text-emerald-600", trend: "+5%" },
          { label: "New Users", value: "1,240", icon: Users, color: "text-purple-600", trend: "+24%" },
          { label: "Global Revenue", value: "₹45.6k", icon: TrendingUp, color: "text-orange-600", trend: "+18%" },
        ].map((stat) => (
          <div key={stat.label} className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className={cn("p-3 rounded-2xl bg-opacity-10", stat.color.replace('text', 'bg'))}>
                <stat.icon className={cn("w-5 h-5", stat.color)} />
              </div>
              <span className="text-[10px] font-black text-emerald-500 bg-emerald-50 px-2 py-1 rounded-md">{stat.trend}</span>
            </div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
            <h3 className="text-2xl font-black text-slate-900">{stat.value}</h3>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Bookings Table */}
        <div className="lg:col-span-2 bg-white rounded-[32px] border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 flex items-center justify-between">
            <h3 className="font-black text-slate-900 flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-600" />
              Live Operations
            </h3>
            <div className="flex bg-slate-50 p-1 rounded-xl">
              <button className="px-4 py-1.5 bg-white shadow-sm rounded-lg text-[10px] font-black text-slate-900 uppercase tracking-widest">Active</button>
              <button className="px-4 py-1.5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Completed</button>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50/50">
                <tr>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Booking ID</th>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Vehicle</th>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Amount</th>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Status</th>
                  <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {bookings.map((booking) => (
                  <tr key={booking.bookingID} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4">
                      <span className="text-[10px] font-black text-slate-900 leading-none">{booking.bookingID}</span>
                      <span className="block text-[8px] text-slate-400 font-bold mt-1 uppercase tracking-tighter">via {booking.paymentMethod}</span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 bg-slate-100 rounded-lg">
                          <Truck className="w-3 h-3 text-slate-500" />
                        </div>
                        <span className="text-xs font-bold text-slate-700 capitalize">{booking.vehicleType}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 font-black text-slate-900 text-xs">₹{booking.totalFare}</td>
                    <td className="px-6 py-4">
                      <span className={cn(
                        "px-2.5 py-1 rounded-full text-[8px] font-black uppercase tracking-widest",
                        booking.status === "confirmed" ? "bg-blue-50 text-blue-600" : "bg-emerald-50 text-emerald-600"
                      )}>
                        {booking.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button className="text-slate-300 hover:text-slate-600 transition-colors">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* System Alerts / Driver Monitoring */}
        <div className="space-y-6">
          <div className="bg-white rounded-[32px] p-6 border border-slate-100 shadow-sm">
            <h3 className="font-black text-slate-900 flex items-center gap-2 mb-6">
              <Shield className="w-4 h-4 text-orange-500" />
              KYC Queue
            </h3>
            <div className="space-y-4">
              {[1, 2].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-slate-200 rounded-xl" />
                    <div>
                      <p className="text-xs font-black text-slate-800">Partner #{100+i}</p>
                      <p className="text-[10px] text-slate-400 font-bold">Docs Uploaded</p>
                    </div>
                  </div>
                  <button className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-[8px] font-black uppercase tracking-widest">Verify</button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-900 rounded-[32px] p-8 text-white relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="text-xl font-black mb-2">Pricing Slabs</h3>
              <p className="text-slate-400 text-xs font-medium mb-6">Modify distance-based rates across sectors.</p>
              <button className="w-full py-4 bg-white/10 hover:bg-white/20 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                Configure Rates
              </button>
            </div>
            <TrendingUp className="absolute -bottom-8 -right-8 w-40 h-40 text-white/5 rotate-12" />
          </div>
        </div>
      </div>
    </div>
  );
}
