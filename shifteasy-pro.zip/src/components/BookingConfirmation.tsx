import { motion } from "motion/react";
import { CheckCircle2, Ticket, MapPin, Navigation2, Calendar, Share2, Home, Package } from "lucide-react";
import { Booking } from "../types";
import { cn } from "../lib/utils";

interface BookingConfirmationProps {
  booking: Booking;
  onClose: () => void;
}

export default function BookingConfirmation({ booking, onClose }: BookingConfirmationProps) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="w-full max-w-lg bg-white rounded-[32px] shadow-2xl overflow-hidden"
      >
        {/* Header - Success Badge */}
        <div className="bg-emerald-500 py-12 flex flex-col items-center justify-center text-white relative">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", damping: 10 }}
            className="bg-white/20 p-4 rounded-full mb-4"
          >
            <CheckCircle2 className="w-12 h-12" />
          </motion.div>
          <h2 className="text-2xl font-bold">Booking Confirmed!</h2>
          <p className="text-emerald-50 opacity-90">Driver assigned and en route</p>
          
          <div className="absolute -bottom-4 bg-white px-4 py-1 rounded-full shadow-sm">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Booking ID: {booking.bookingID}</span>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 pt-10 space-y-6 max-h-[60vh] overflow-y-auto custom-scrollbar">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Total Fare</label>
              <div className="text-3xl font-black text-slate-900">₹{booking.totalFare}</div>
              <div className="flex items-center gap-1.5">
                <div className={cn(
                  "w-1.5 h-1.5 rounded-full",
                  booking.paymentMethod === "cash" ? "bg-orange-500" : "bg-blue-500"
                )} />
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">via {booking.paymentMethod}</span>
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Vehicle</label>
              <div className="text-xl font-bold text-slate-700 capitalize">{booking.vehicleType.replace('_', ' ')}</div>
            </div>
          </div>

          {/* Item Details Section */}
          <div className="bg-slate-50 rounded-[24px] p-5 space-y-3">
            <div className="flex items-center gap-2 mb-1">
              <Package className="w-4 h-4 text-blue-600" />
              <span className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Item Information</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-[8px] font-black text-slate-400 uppercase">Item Name</span>
                <p className="text-xs font-bold text-slate-700">{booking.itemDetails.itemName}</p>
              </div>
              <div>
                <span className="text-[8px] font-black text-slate-400 uppercase">Weight / Qty</span>
                <p className="text-xs font-bold text-slate-700">{booking.itemDetails.weight}kg x {booking.itemDetails.quantity}</p>
              </div>
            </div>
            {booking.itemDetails.itemPhoto && (
              <div className="mt-2 w-full aspect-video rounded-xl overflow-hidden border border-slate-200">
                <img 
                  src={booking.itemDetails.itemPhoto} 
                  alt="Item" 
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            {booking.itemDetails.fragile && (
              <div className="bg-amber-100 text-amber-700 text-[8px] font-black uppercase px-2 py-1 rounded-md inline-block">
                ⚠️ Fragile Item
              </div>
            )}
          </div>

          <div className="border-t border-slate-100 pt-6 space-y-4">
            <div className="flex items-start gap-3">
              <div className="bg-blue-50 p-2 rounded-lg mt-1">
                <MapPin className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Pickup</label>
                <p className="text-slate-900 font-medium text-xs leading-relaxed">{booking.pickup.address}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-orange-50 p-2 rounded-lg mt-1">
                <Navigation2 className="w-4 h-4 text-orange-600" />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Drop Off</label>
                <p className="text-slate-900 font-medium text-xs leading-relaxed">{booking.drop.address}</p>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-slate-400" />
              <div className="text-sm font-medium text-slate-600">
                Today, {new Date(booking.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
            <div className="text-[10px] font-bold text-blue-600 bg-blue-100 px-2 py-1 rounded">ON-DEMAND</div>
          </div>
        </div>
        <div className="p-8 pt-0 flex gap-3">
            <button
              onClick={onClose}
              className="flex-1 bg-slate-900 text-white h-14 rounded-2xl font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
            >
              <Home className="w-5 h-5" />
              Back Home
            </button>
            <button className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center hover:bg-slate-200 transition-all">
              <Share2 className="w-6 h-6 text-slate-600" />
            </button>
          </div>
        </motion.div>
      </div>
    );
  }
