import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { CreditCard, ShieldCheck, Lock, ChevronRight, X } from "lucide-react";
import { cn } from "../lib/utils";

interface OnlinePaymentGatewayProps {
  amount: number;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function OnlinePaymentGateway({ amount, onSuccess, onCancel }: OnlinePaymentGatewayProps) {
  const [step, setStep] = useState<"details" | "processing" | "success">("details");
  const [cardNumber, setCardNumber] = useState("");

  const handlePay = () => {
    setStep("processing");
    setTimeout(() => {
      setStep("success");
      setTimeout(onSuccess, 1500);
    }, 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[110] bg-slate-900/90 backdrop-blur-sm flex items-center justify-center p-4"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-[32px] overflow-hidden shadow-2xl"
      >
        <div className="p-8 border-b border-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-black text-slate-900 leading-none">Secure Pay</h2>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">ShiftEasy Logistics</p>
            </div>
          </div>
          <button onClick={onCancel} className="p-2 text-slate-300 hover:text-slate-600 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-8">
          <AnimatePresence mode="wait">
            {step === "details" && (
              <motion.div 
                key="details"
                initial={{ x: 20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -20, opacity: 0 }}
                className="space-y-6"
              >
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 mb-6">
                  <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Amount to Pay</div>
                  <div className="text-3xl font-black text-slate-900">₹{amount.toLocaleString()}</div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Card Number</label>
                    <div className="relative">
                      <CreditCard className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        type="text" 
                        placeholder="4242 4242 4242 4242"
                        value={cardNumber}
                        onChange={(e) => setCardNumber(e.target.value.replace(/\s?/g, '').replace(/(\d{4})/g, '$1 ').trim())}
                        className="w-full pl-11 pr-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-sm font-bold transition-all"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Expiry</label>
                      <input type="text" placeholder="MM/YY" className="w-full px-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-sm font-bold transition-all" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">CVV</label>
                      <input type="password" placeholder="***" className="w-full px-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-sm font-bold transition-all" />
                    </div>
                  </div>
                </div>

                <button 
                  onClick={handlePay}
                  className="w-full h-14 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-600/20 flex items-center justify-center gap-2 hover:bg-blue-700 active:scale-95 transition-all"
                >
                  Confirm Payment
                  <ChevronRight className="w-4 h-4 opacity-50" />
                </button>

                <div className="flex items-center justify-center gap-2 opacity-40">
                  <Lock className="w-3 h-3" />
                  <span className="text-[9px] font-bold uppercase tracking-widest">End-to-end encrypted</span>
                </div>
              </motion.div>
            )}

            {step === "processing" && (
              <motion.div 
                key="processing"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="py-12 flex flex-col items-center justify-center space-y-6"
              >
                <div className="relative">
                  <div className="w-16 h-16 border-4 border-blue-50 border-t-blue-600 rounded-full animate-spin" />
                  <Lock className="absolute inset-0 m-auto w-5 h-5 text-blue-600/50" />
                </div>
                <div className="text-center">
                  <h3 className="font-bold text-slate-900">Processing Payment</h3>
                  <p className="text-xs text-slate-400 mt-1">Verifying with your bank...</p>
                </div>
              </motion.div>
            )}

            {step === "success" && (
              <motion.div 
                key="success"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="py-12 flex flex-col items-center justify-center space-y-6"
              >
                <div className="w-20 h-20 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center shadow-inner">
                  <ShieldCheck className="w-10 h-10" />
                </div>
                <div className="text-center">
                  <h3 className="font-black text-slate-900 text-xl">Payment Successful</h3>
                  <p className="text-sm text-slate-500 mt-1">Receipt sent to your email.</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </motion.div>
  );
}
