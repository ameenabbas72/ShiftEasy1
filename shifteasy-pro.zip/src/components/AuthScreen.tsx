import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Zap, LogIn, ChevronRight, ShieldCheck, Mail, Lock, User, ArrowLeft } from "lucide-react";
import { signInWithGoogle, signInWithEmail, signUpWithEmail } from "../lib/firebase";

interface AuthScreenProps {
  onAuthComplete: (user: any) => void;
}

export default function AuthScreen({ onAuthComplete }: AuthScreenProps) {
  const [step, setStep] = useState<"login" | "email_auth" | "otp">("login");
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin");
  const [loading, setLoading] = useState(false);
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [tempUser, setTempUser] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  // Email form state
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  const handleGoogleLogin = async () => {
    setLoading(true);
    setError(null);
    try {
      const user = await signInWithGoogle();
      setTempUser(user);
      setStep("otp");
    } catch (err: any) {
      setError(err.message || "Failed to login with Google");
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      let user;
      if (authMode === "signup") {
        if (!name) throw new Error("Name is required");
        user = await signUpWithEmail(email, password, name);
      } else {
        user = await signInWithEmail(email, password);
      }
      setTempUser(user);
      setStep("otp");
    } catch (err: any) {
      setError(err.message || "Authentication failed");
    } finally {
      setLoading(false);
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next
    if (value && index < 3) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const verifyOtp = () => {
    if (otp.join("").length === 4) {
      setLoading(true);
      setTimeout(() => {
        onAuthComplete(tempUser);
        setLoading(false);
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-slate-100 flex items-center justify-center p-6 overflow-y-auto">
      <div className="w-full max-w-sm py-8">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-blue-600 rounded-[20px] flex items-center justify-center shadow-2xl shadow-blue-600/30 mb-6">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight">ShiftEasy</h1>
          <p className="text-slate-500 font-medium">Logistics simplified.</p>
        </div>

        <AnimatePresence mode="wait">
          {step === "login" && (
            <motion.div
              key="login"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ x: -50, opacity: 0 }}
              className="space-y-4"
            >
              <button
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full h-16 bg-white border-2 border-slate-100 rounded-[24px] flex items-center justify-center gap-4 hover:border-blue-500 transition-all group active:scale-95 shadow-sm"
              >
                {loading ? (
                  <div className="w-6 h-6 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                    </svg>
                    <span className="font-bold text-slate-700">Continue with Google</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setStep("email_auth")}
                className="w-full h-16 bg-slate-100 rounded-[24px] flex items-center justify-center gap-4 hover:border-slate-300 transition-all group active:scale-95"
              >
                <Mail className="w-5 h-5 text-slate-400 group-hover:text-blue-600 transition-colors" />
                <span className="font-bold text-slate-600">Continue with Email</span>
              </button>
              
              <div className="text-center mt-6">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest leading-loose px-8">
                  By continuing, you agree to ShiftEasy's Privacy Policy and Logistics Terms.
                </p>
              </div>
            </motion.div>
          )}

          {step === "email_auth" && (
            <motion.div
              key="email"
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 50, opacity: 0 }}
              className="bg-white p-8 rounded-[32px] shadow-2xl border border-slate-100 space-y-6"
            >
              <div className="flex items-center gap-3 mb-2">
                <button onClick={() => setStep("login")} className="p-2 hover:bg-slate-50 rounded-xl transition-colors">
                  <ArrowLeft className="w-4 h-4 text-slate-400" />
                </button>
                <h2 className="text-xl font-bold text-slate-900">{authMode === "signin" ? "Welcome Back" : "Create Account"}</h2>
              </div>

              <form onSubmit={handleEmailAuth} className="space-y-4">
                {authMode === "signup" && (
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Full Name</label>
                    <div className="relative">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input 
                        required
                        type="text" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="John Doe" 
                        className="w-full pl-11 pr-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-sm font-bold transition-all"
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      required
                      type="email" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@email.com" 
                      className="w-full pl-11 pr-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-sm font-bold transition-all"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input 
                      required
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••" 
                      className="w-full pl-11 pr-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-sm font-bold transition-all"
                    />
                  </div>
                </div>

                {error && <div className="text-[10px] bg-red-50 text-red-500 p-3 rounded-xl font-bold uppercase">{error}</div>}

                <button 
                  type="submit"
                  disabled={loading}
                  className="w-full h-14 bg-blue-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-blue-600/20 flex items-center justify-center gap-2 hover:bg-blue-700 active:scale-95 transition-all"
                >
                  {loading ? "Please wait..." : (authMode === "signin" ? "Sign In" : "Register")}
                  <ChevronRight className="w-4 h-4 opacity-50" />
                </button>
              </form>

              <button 
                onClick={() => setAuthMode(authMode === "signin" ? "signup" : "signin")}
                className="w-full text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors"
              >
                {authMode === "signin" ? "New to ShiftEasy? Create account" : "Already have an account? Sign In"}
              </button>
            </motion.div>
          )}

          {step === "otp" && (
            <motion.div
              key="otp"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="bg-white p-8 rounded-[32px] shadow-2xl border border-slate-100 space-y-6"
            >
              <div className="text-center space-y-2">
                <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <ShieldCheck className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-bold text-slate-900">Verify Identity</h2>
                <p className="text-sm text-slate-500">Enter the 4-digit code sent to your email.</p>
              </div>

              <div className="flex justify-center gap-3">
                {otp.map((digit, i) => (
                  <input
                    key={i}
                    id={`otp-${i}`}
                    type="number"
                    value={digit}
                    onChange={(e) => handleOtpChange(i, e.target.value)}
                    className="w-14 h-16 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-center text-2xl font-black focus:ring-0 transition-all text-slate-800"
                  />
                ))}
              </div>

              <button
                onClick={verifyOtp}
                disabled={otp.join("").length < 4 || loading}
                className="w-full h-14 bg-slate-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 disabled:opacity-30 active:scale-95 transition-all shadow-xl shadow-slate-900/10"
              >
                {loading ? "Verifying..." : "Verify & Start Shifting"}
                <ChevronRight className="w-5 h-5 opacity-50" />
              </button>

              <button 
                onClick={() => setStep("login")}
                className="w-full text-sm font-bold text-slate-400 hover:text-slate-600"
              >
                Back to login
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
