import { motion } from "motion/react";
import { X, Package, Truck, Ship, Phone, Mail, MessageSquare, ShieldCheck, MapPin, CreditCard, Bell, LogOut, History, Info, Settings, LayoutDashboard, Bike } from "lucide-react";
import { Booking, VEHICLES } from "../types";
import { useEffect, useState } from "react";
import { db, auth, logout } from "../lib/firebase";
import { collection, query, where, getDocs, orderBy } from "firebase/firestore";
import { cn } from "../lib/utils";
import AdminPanel from "./AdminPanel";
import { handleFirestoreError, OperationType } from "../lib/firestore-errors";

type PanelType = "services" | "bookings" | "support" | "profile" | "admin";

interface NavigationPanelsProps {
  activePanel: PanelType;
  onClose: () => void;
  onSwitchPanel: (panel: PanelType) => void;
}

export default function NavigationPanels({ activePanel, onClose, onSwitchPanel }: NavigationPanelsProps) {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (activePanel === "bookings" && auth.currentUser) {
      setLoading(true);
      const fetchBookings = async () => {
        try {
          const q = query(
            collection(db, "bookings"),
            where("userId", "==", auth.currentUser?.uid),
            orderBy("timestamp", "desc")
          );
          const querySnapshot = await getDocs(q);
          const docs: Booking[] = [];
          querySnapshot.forEach((doc) => docs.push(doc.data() as Booking));
          setBookings(docs);
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "bookings");
        } finally {
          setLoading(false);
        }
      };
      fetchBookings();
    }
  }, [activePanel]);

  const renderContent = () => {
    switch (activePanel) {
      case "admin":
        return <AdminPanel />;
      case "services":
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-black text-slate-900">Our Fleet</h2>
            <div className="grid gap-4">
              {VEHICLES.map((v) => {
                const Icon = v.id === "bike" ? Bike : v.id === "auto" ? Package : Truck;
                return (
                  <div key={v.id} className="bg-white p-6 rounded-[24px] border border-slate-100 shadow-sm flex items-center gap-5">
                    <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl">
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-900">{v.name}</h3>
                      <p className="text-xs text-slate-500">{v.description}</p>
                      <div className="mt-2 text-[10px] font-black text-blue-600 tracking-widest uppercase">
                        Base: ₹{v.baseFare} + ₹{v.perKm}/KM
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );

      case "bookings":
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-black text-slate-900">History</h2>
            {loading ? (
              <div className="flex justify-center py-12">
                <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : bookings.length > 0 ? (
              <div className="space-y-4">
                {bookings.map((b) => (
                  <div key={b.bookingID} className="bg-white p-5 rounded-[24px] border border-slate-100 shadow-sm space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="text-[10px] font-black text-slate-400 tracking-tighter">REF: {b.bookingID}</div>
                        <div className="text-lg font-black text-slate-900">₹{b.totalFare}</div>
                      </div>
                      <div className="bg-emerald-100 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider">
                        {b.status}
                      </div>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-slate-600">
                        <MapPin className="w-4 h-4 text-blue-500" />
                        <span className="truncate text-xs font-medium">{b.pickup.address}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-600 text-xs font-medium">
                        <Package className="w-4 h-4 text-slate-400" />
                        <span>{b.itemDetails.itemName} ({b.itemDetails.weight}kg)</span>
                      </div>
                    </div>
                    <div className="pt-3 border-t border-slate-50 flex justify-between items-center text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                      <span>{new Date(b.timestamp).toLocaleDateString()}</span>
                      <span>{b.distance} KM</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-slate-50 rounded-[32px] border-2 border-dashed border-slate-200">
                <History className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500 font-medium">No bookings yet</p>
              </div>
            )}
          </div>
        );

      case "support":
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-black text-slate-900">24/7 Support</h2>
            <div className="grid grid-cols-1 gap-4">
              <a 
                href="tel:+1800SHIFTEASY"
                className="flex items-center gap-4 bg-white p-5 rounded-[24px] border border-slate-100 hover:border-blue-500 transition-all text-left group"
              >
                <div className="p-3 bg-blue-50 text-blue-600 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-slate-900">Call Support</div>
                  <div className="text-xs text-slate-500">Avg. wait time: 2 mins</div>
                </div>
              </a>
              <button 
                onClick={() => alert("Launching ShiftEasy AI Assistant... How can we help you today?")}
                className="flex items-center gap-4 bg-white p-5 rounded-[24px] border border-slate-100 hover:border-emerald-500 transition-all text-left group"
              >
                <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-slate-900">Chat with AI</div>
                  <div className="text-xs text-slate-500">Instant response</div>
                </div>
              </button>
            </div>
          </div>
        );

      case "profile":
        return (
          <div className="space-y-8">
            <div className="flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-[32px] bg-slate-100 border-4 border-white shadow-xl flex items-center justify-center text-slate-400 mb-4 relative overflow-hidden">
                <div className="absolute -top-2 -right-2 bg-emerald-500 text-white p-1.5 rounded-full border-4 border-slate-50 z-10">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                {auth.currentUser?.photoURL ? (
                  <img src={auth.currentUser.photoURL} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <div className="text-4xl font-black text-slate-300">
                    {auth.currentUser?.displayName?.split(' ').map(n => n[0]).join('').toUpperCase() || '??'}
                  </div>
                )}
              </div>
              <h2 className="text-2xl font-black text-slate-900">{auth.currentUser?.displayName || "ShiftEasy User"}</h2>
              <p className="text-slate-500 text-sm font-medium">{auth.currentUser?.email || "No email provided"}</p>
            </div>

            <div className="space-y-3">
              {[
                { icon: LayoutDashboard, label: "Admin Dashboard", detail: "Manage platform", action: () => onSwitchPanel("admin") },
                { icon: MapPin, label: "Saved Addresses", detail: "3 locations", action: () => {} },
                { icon: CreditCard, label: "Payment Methods", detail: "Visa ending in 4242", action: () => {} },
                { icon: Bell, label: "Notification Settings", detail: "On", action: () => {} },
              ].map((item, idx) => (
                <button 
                  key={idx} 
                  onClick={item.action}
                  className="w-full flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-50 hover:bg-slate-50 transition-colors active:scale-[0.98]"
                >
                  <div className="flex items-center gap-3">
                    <item.icon className="w-5 h-5 text-slate-400 group-hover:text-blue-500" />
                    <div className="text-left">
                      <div className="text-sm font-bold text-slate-800">{item.label}</div>
                      <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{item.detail}</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            <button 
              onClick={async () => {
                setLoading(true);
                try {
                  await logout();
                } catch (error) {
                  console.error("Logout failed:", error);
                  setLoading(false);
                }
              }}
              disabled={loading}
              className="w-full flex items-center justify-center gap-3 py-5 text-red-500 font-black text-xs uppercase tracking-widest border-2 border-red-50 rounded-2xl hover:bg-red-50 transition-all active:scale-95 disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-red-500 border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </>
              )}
            </button>
          </div>
        );
    }
  };

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "spring", damping: 25, stiffness: 200 }}
      className="fixed inset-y-0 right-0 z-50 w-full max-w-lg bg-slate-50 shadow-2xl flex flex-col border-l border-slate-200"
    >
      <div className="p-6 flex items-center justify-between border-b border-slate-200 bg-white">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white font-black text-xs">
            {activePanel[0].toUpperCase()}
          </div>
          <span className="font-black text-slate-900 capitalize tracking-tight">{activePanel}</span>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
          <X className="w-6 h-6 text-slate-400" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-8 no-scrollbar pb-32">
        {renderContent()}
      </div>

      <div className="p-6 bg-white border-t border-slate-100">
        <p className="text-[10px] text-slate-400 font-bold text-center uppercase tracking-widest leading-loose">
          ShiftEasy Logistics System • v2.1.0
        </p>
      </div>
    </motion.div>
  );
}

