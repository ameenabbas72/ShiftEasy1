import { useEffect, useState } from "react";
import { Marker, useMap } from "@vis.gl/react-google-maps";
import { Truck, Bike, Package } from "lucide-react";

interface Driver {
  id: string;
  lat: number;
  lng: number;
  type: "bike" | "auto" | "truck";
  heading: number;
}

const INITIAL_DRIVERS: Driver[] = [
  { id: "1", lat: 12.9716, lng: 77.5946, type: "truck", heading: 45 },
  { id: "2", lat: 12.9816, lng: 77.5846, type: "bike", heading: 90 },
  { id: "3", lat: 12.9616, lng: 77.6046, type: "auto", heading: 180 },
  { id: "4", lat: 12.9516, lng: 77.5746, type: "truck", heading: 270 },
];

export default function DriverMarkers() {
  const [drivers, setDrivers] = useState<Driver[]>(INITIAL_DRIVERS);
  const map = useMap();

  useEffect(() => {
    const interval = setInterval(() => {
      setDrivers(prev => prev.map(d => ({
        ...d,
        lat: d.lat + (Math.random() - 0.5) * 0.001,
        lng: d.lng + (Math.random() - 0.5) * 0.001,
        heading: d.heading + (Math.random() - 0.5) * 10
      })));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <>
      {drivers.map(driver => (
        <Marker
          key={driver.id}
          position={{ lat: driver.lat, lng: driver.lng }}
        >
          {/* We can't easily render custom SVG icons in Marker without extra setup, 
              but we can use the default or a simple custom one */}
        </Marker>
      ))}
    </>
  );
}
