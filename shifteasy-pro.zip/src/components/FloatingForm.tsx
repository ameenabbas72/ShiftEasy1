import React, { useState, useEffect, useRef } from "react";
import { 
  ArrowRightLeft, Package, Truck, Ship, Navigation2, 
  Wallet, CreditCard, ChevronRight, ChevronLeft, 
  Box, Info, HardHat, Moon, Zap,
  Camera, Briefcase, Sofa, ClipboardList, Bike
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { VEHICLES, VehicleType, ItemDetails, Booking } from "../types";
import { cn } from "../lib/utils";
import { calculateDetailedFare } from "../lib/utils/fare";

interface FloatingFormProps {
  onBook: (data: Partial<Booking>) => void;
}

type FormStep = "locations" | "items" | "vehicles";

export default function FloatingForm({ onBook }: FloatingFormProps) {
  const [step, setStep] = useState<FormStep>("locations");
  const [pickup, setPickup] = useState("");
  const [drop, setDrop] = useState("");
  const [distance, setDistance] = useState<number>(0);
  
  // Item Details
  const [itemName, setItemName] = useState("");
  const [category, setCategory] = useState("General");
  const [weight, setWeight] = useState(50);
  const [quantity, setQuantity] = useState(1);
  const [fragile, setFragile] = useState(false);
  const [specialInstructions, setSpecialInstructions] = useState("");
  const [itemPhoto, setItemPhoto] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType>("auto");
  const [paymentMethod, setPaymentMethod] = useState<Booking["paymentMethod"]>("cash");
  const [isNight] = useState(new Date().getHours() > 20 || new Date().getHours() < 6);

  const vehicle = VEHICLES.find(v => v.id === selectedVehicle)!;
  const fareBreakdown = calculateDetailedFare(distance, vehicle, weight, isNight);

  const categories = [
    { name: "Furniture", icon: Sofa },
    { name: "Groceries", icon: Package },
    { name: "Electronics", icon: Zap },
    { name: "Documents", icon: Briefcase },
    { name: "General", icon: Box },
  ];

  // Auto-suggest vehicle based on weight
  useEffect(() => {
    if (step === "items") {
      if (weight <= 20) setSelectedVehicle("bike");
      else if (weight <= 250) setSelectedVehicle("auto");
      else if (weight <= 750) setSelectedVehicle("tata_ace");
      else if (weight <= 1200) setSelectedVehicle("mini_tempo");
      else if (weight <= 2500) setSelectedVehicle("big_tempo");
      else setSelectedVehicle("truck");
    }
  }, [weight, step]);

  const handleBooking = () => {
    const bookingData: Partial<Booking> = {
      pickup: { address: pickup, lat: 0, lng: 0 },
      drop: { address: drop, lat: 0, lng: 0 },
      distance,
      vehicleType: selectedVehicle,
      itemDetails: {
        itemName,
        category,
        weight,
        quantity,
        fragile,
        specialInstructions,
        itemPhoto
      },
      fareBreakdown,
      totalFare: fareBreakdown.total,
      paymentMethod,
      timestamp: new Date().toISOString(),
      status: "searching"
    };
    onBook(bookingData);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("File size too large. Please upload an image under 5MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setItemPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="w-full h-full flex flex-col lg:flex-row gap-6 items-start lg:items-end justify-between pointer-events-none pb-4">
      {/* Left Panel: Location & Item Details */}
      <motion.div
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        className="w-full max-w-sm bg-white rounded-[32px] p-6 shadow-2xl pointer-events-auto shrink-0 self-start mt-0 lg:mt-4 mb-4 lg:mb-0 border border-slate-100 flex flex-col max-h-[85vh] overflow-hidden"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex gap-1.5">
            {[1, 2, 3].map((i) => (
              <div 
                key={i} 
                className={cn(
                  "h-1 rounded-full transition-all duration-500",
                  (step === "locations" && i === 1) || (step === "items" && i === 2) || (step === "vehicles" && i === 3)
                    ? "w-8 bg-blue-600" 
                    : i < (step === "locations" ? 1 : step === "items" ? 2 : 3) ? "w-4 bg-emerald-500" : "w-4 bg-slate-100"
                )}
              />
            ))}
          </div>
          {step !== "locations" && (
            <button 
              onClick={() => setStep(step === "items" ? "locations" : "items")}
              className="p-2 hover:bg-slate-100 rounded-xl transition-colors"
            >
              <ChevronLeft className="w-4 h-4 text-slate-400" />
            </button>
          )}
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar pr-1 -mr-1">
          <AnimatePresence mode="wait">
            {step === "locations" && (
              <motion.div
                key="loc"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                    <Navigation2 className="w-5 h-5 text-blue-600" />
                    Trip Details
                  </h2>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Set your route</p>
                </div>
                
                <div className="space-y-3 relative">
                  <div className="absolute left-3 top-3 w-0.5 h-[calc(100%-24px)] bg-slate-100" />
                  
                  <div className="relative">
                    <div className="absolute left-2.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
                    <input
                      type="text"
                      placeholder="Enter Pickup Location"
                      value={pickup}
                      onChange={(e) => setPickup(e.target.value)}
                      className="w-full pl-9 pr-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl text-sm focus:ring-0 transition-all font-bold text-slate-700 placeholder:text-slate-400 shadow-sm"
                    />
                  </div>

                  <div className="relative">
                    <div className="absolute left-2.5 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]" />
                    <input
                      type="text"
                      placeholder="Enter Drop Location"
                      value={drop}
                      onChange={(e) => setDrop(e.target.value)}
                      className="w-full pl-9 pr-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 focus:bg-white rounded-2xl text-sm focus:ring-0 transition-all font-bold text-slate-700 placeholder:text-slate-400 shadow-sm"
                    />
                  </div>

                  <div className="flex gap-3 pt-2">
                    <div className="flex-1 flex items-center bg-blue-50/50 px-4 py-3 rounded-2xl border border-blue-100 shadow-inner">
                      <ArrowRightLeft className="w-4 h-4 text-blue-600 mr-2 opacity-70" />
                      <input
                        type="number"
                        placeholder="0"
                        value={distance || ""}
                        onChange={(e) => setDistance(Math.max(0, Number(e.target.value)))}
                        className="bg-transparent border-none focus:ring-0 text-sm font-black text-blue-700 w-full placeholder:text-blue-300"
                      />
                      <span className="text-[10px] font-black text-blue-400 ml-1">KM</span>
                    </div>
                  </div>
                </div>

                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-100 flex gap-3">
                  <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <p className="text-[10px] text-amber-700 font-bold leading-relaxed">
                    Distance calculations are used for initial pricing. Final route determined by driver GPS.
                  </p>
                </div>
              </motion.div>
            )}

            {step === "items" && (
              <motion.div
                key="items"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                    <ClipboardList className="w-5 h-5 text-blue-600" />
                    Item Details
                  </h2>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">What are you moving?</p>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Item Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Wooden Dining Table"
                      value={itemName}
                      onChange={e => setItemName(e.target.value)}
                      className="w-full px-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-sm font-bold transition-all"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Weight (KG)</label>
                      <input 
                        type="number" 
                        value={weight}
                        onChange={e => setWeight(Number(e.target.value))}
                        className="w-full px-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-sm font-bold transition-all"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Quantity</label>
                      <input 
                        type="number" 
                        value={quantity}
                        onChange={e => setQuantity(Number(e.target.value))}
                        className="w-full px-4 py-4 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-sm font-bold transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Category</label>
                    <div className="flex gap-2 p-1 bg-slate-50 rounded-2xl overflow-x-auto custom-scrollbar no-scrollbar scrollbar-hide">
                      {categories.map(cat => {
                        const Icon = cat.icon;
                        return (
                          <button
                            key={cat.name}
                            onClick={() => setCategory(cat.name)}
                            className={cn(
                              "flex flex-col items-center gap-1.5 px-4 py-3 rounded-xl transition-all shrink-0 min-w-[70px]",
                              category === cat.name ? "bg-white shadow-md text-blue-600 scale-105" : "text-slate-400 hover:text-slate-600"
                            )}
                          >
                            <Icon className="w-4 h-4" />
                            <span className="text-[8px] font-black uppercase tracking-wider">{cat.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-4 bg-slate-50/50 border-2 border-slate-100 rounded-2xl cursor-pointer hover:bg-slate-50 transition-colors" onClick={() => setFragile(!fragile)}>
                    <div className={cn(
                      "w-10 h-6 rounded-full relative transition-colors duration-300",
                      fragile ? "bg-blue-600" : "bg-slate-200"
                    )}>
                      <div className={cn(
                        "absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 shadow-sm",
                        fragile ? "left-5" : "left-1"
                      )} />
                    </div>
                    <span className="text-xs font-bold text-slate-700">Handle as Fragile Item</span>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Special Instructions</label>
                    <textarea 
                      placeholder="e.g. Call before arrival, 3rd floor..."
                      value={specialInstructions}
                      onChange={e => setSpecialInstructions(e.target.value)}
                      className="w-full px-4 py-3 bg-slate-50 border-2 border-transparent focus:border-blue-500 rounded-2xl text-xs font-bold transition-all h-20 resize-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase ml-1">Item Image</label>
                    <div className="relative group">
                      <input 
                        type="file" 
                        accept="image/*" 
                        ref={fileInputRef}
                        className="hidden" 
                        onChange={handlePhotoUpload}
                      />
                      {itemPhoto ? (
                        <div className="relative w-full aspect-video rounded-2xl overflow-hidden border-2 border-blue-100 mb-2">
                          <img 
                            src={itemPhoto} 
                            alt="Item preview" 
                            className="w-full h-full object-cover"
                          />
                          <button 
                            onClick={() => setItemPhoto(null)}
                            className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Box className="w-3 h-3 rotate-45" />
                          </button>
                        </div>
                      ) : (
                        <button 
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="w-full flex flex-col items-center justify-center gap-2 py-8 bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl text-slate-400 hover:border-blue-300 hover:text-blue-500 hover:bg-white transition-all active:scale-[0.98]"
                        >
                          <Camera className="w-6 h-6 mb-1" />
                          <span className="text-[10px] font-black uppercase tracking-widest">Tap to upload item photo</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <button
          onClick={() => {
            if (step === "locations") {
              if (pickup && drop && distance > 0) setStep("items");
            } else if (step === "items") {
              if (itemName) setStep("vehicles");
            }
          }}
          disabled={(step === "locations" && (!pickup || !drop || distance <= 0)) || (step === "items" && !itemName)}
          className="mt-6 w-full bg-blue-600 text-white h-14 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-blue-600/20 flex items-center justify-center gap-2 hover:bg-blue-700 active:scale-95 transition-all disabled:opacity-30 disabled:grayscale"
        >
          {step === "locations" ? "Next: Item Details" : step === "items" ? "Next: Select Vehicle" : "Next"}
          <ChevronRight className="w-4 h-4" />
        </button>
      </motion.div>

      {/* Right Panel: Vehicle Selection & Payment */}
      <AnimatePresence>
        {step === "vehicles" && (
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            className="w-full pointer-events-auto flex flex-col gap-4 max-w-4xl"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {VEHICLES.map((v) => {
                const Icon = v.id === "bike" ? Bike : v.id === "auto" ? Package : Truck;
                const breakdown = calculateDetailedFare(distance, v, weight, isNight);
                const isSelected = selectedVehicle === v.id;

                return (
                  <motion.button
                    key={v.id}
                    whileHover={{ y: -4 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedVehicle(v.id)}
                    className={cn(
                      "relative group bg-white p-5 rounded-[28px] text-left transition-all duration-300 border-2 overflow-hidden",
                      isSelected 
                        ? "border-blue-500 shadow-2xl shadow-blue-500/10" 
                        : "border-slate-50 shadow-lg shadow-slate-200/50 opacity-60 hover:opacity-100"
                    )}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className={cn(
                        "p-3 rounded-2xl transition-colors",
                        isSelected ? "bg-blue-600 text-white" : "bg-slate-100 text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-500"
                      )}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <div className="text-right">
                        <span className="block text-lg font-black text-slate-900 leading-none">₹{breakdown.total}</span>
                        <span className="text-[7px] font-black text-blue-500/60 uppercase mt-1 block">
                          ₹{v.baseFare} Base + Slabs
                        </span>
                      </div>
                    </div>

                    <h3 className="font-bold text-slate-800 text-xs flex items-center justify-between">
                      {v.name}
                      <span className="text-[8px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-md font-black">
                        {v.capacity}KG Max
                      </span>
                    </h3>
                    <p className="text-[9px] text-slate-500 mt-1 leading-relaxed opacity-70 truncate">{v.description}</p>
                    
                    {isSelected && (
                      <motion.div 
                        layoutId="active-vehicle"
                        className="mt-3 h-1 w-full bg-blue-500 rounded-full" 
                      />
                    )}
                  </motion.button>
                );
              })}
            </div>

            {/* Price Breakdown Footer */}
            <div className="bg-white rounded-[32px] p-6 shadow-2xl border border-slate-100 flex flex-col md:flex-row gap-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 flex-1 gap-6">
                <div>
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-2">Distance Fare</span>
                  <div className="flex items-end gap-1">
                    <span className="text-xl font-black text-slate-900">₹{fareBreakdown.distanceFare}</span>
                    <span className="text-[9px] font-bold text-slate-400 mb-1">({distance}km)</span>
                  </div>
                </div>
                <div>
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-2">Service Tax (GST)</span>
                  <div className="flex items-end gap-1">
                    <span className="text-xl font-black text-slate-900">₹{fareBreakdown.gst}</span>
                    <span className="text-[9px] font-bold text-slate-400 mb-1">(18%)</span>
                  </div>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex items-center gap-3">
                  {isNight ? <Moon className="w-4 h-4 text-indigo-500" /> : <HardHat className="w-4 h-4 text-emerald-500" />}
                  <div>
                    <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest block">{isNight ? "Night Charge" : "Standard Rate"}</span>
                    <span className="text-xs font-black text-slate-800 tracking-tight">{isNight ? `+₹${fareBreakdown.nightCharge}` : "0 Extra"}</span>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Payment Mode</span>
                  <div className="flex gap-2">
                    {(['cash', 'upi', 'card'] as const).map(p => (
                      <button
                        key={p}
                        onClick={() => setPaymentMethod(p)}
                        className={cn(
                          "flex-1 py-2 px-3 rounded-xl border-2 text-[8px] font-black uppercase tracking-wider transition-all",
                          paymentMethod === p ? "border-blue-600 bg-blue-600 text-white" : "border-slate-100 text-slate-400 hover:border-slate-200"
                        )}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="border-t md:border-t-0 md:border-l border-slate-100 pt-6 md:pt-0 md:pl-6 flex flex-col justify-center min-w-[180px]">
                <div className="mb-2">
                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Final Amount</span>
                  <div className="text-3xl font-black text-slate-900 tracking-tight">₹{fareBreakdown.total}</div>
                </div>
                <button
                  onClick={handleBooking}
                  className="w-full bg-slate-900 text-white h-14 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-800 active:scale-[0.98] transition-all shadow-xl shadow-slate-900/20"
                >
                  Book {vehicle.name}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
