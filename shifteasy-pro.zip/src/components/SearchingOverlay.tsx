import { motion } from "motion/react";
import { Radar, Package, Truck, Ship, Bike } from "lucide-react";
import { VehicleType, VEHICLES } from "../types";

interface SearchingOverlayProps {
  vehicleType: VehicleType;
  onCancel: () => void;
}

export default function SearchingOverlay({ vehicleType, onCancel }: SearchingOverlayProps) {
  const vehicle = VEHICLES.find(v => v.id === vehicleType);
  const Icon = vehicleType === "bike" ? Bike : vehicleType === "auto" ? Package : Truck;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6 sm:p-24 bg-slate-900/60 backdrop-blur-lg">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-sm bg-white rounded-[40px] p-10 text-center shadow-2xl space-y-8 relative overflow-hidden"
      >
        {/* Animated Background Rings */}
        <div className="absolute inset-0 z-0 flex items-center justify-center">
          <motion.div
            animate={{ scale: [1, 2], opacity: [0.3, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeOut" }}
            className="absolute w-40 h-40 border-2 border-blue-100 rounded-full"
          />
          <motion.div
            animate={{ scale: [1, 2], opacity: [0.2, 0] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeOut", delay: 0.5 }}
            className="absolute w-40 h-40 border-2 border-blue-200 rounded-full"
          />
        </div>

        <div className="relative z-10 space-y-6">
          <div className="relative w-32 h-32 mx-auto">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
              className="absolute inset-0 border-4 border-dashed border-blue-500/20 rounded-full"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-blue-600 p-6 rounded-3xl shadow-lg shadow-blue-600/30">
                <Icon className="w-12 h-12 text-white" />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-slate-900 leading-tight">Searching for Drivers</h2>
            <p className="text-slate-500 text-sm">Finding the nearest {vehicle?.name} for your shift...</p>
          </div>

          <div className="flex justify-center gap-1.5">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                animate={{ scale: [1, 1.5, 1], opacity: [0.4, 1, 0.4] }}
                transition={{ repeat: Infinity, duration: 1, delay: i * 0.2 }}
                className="w-2 h-2 bg-blue-600 rounded-full"
              />
            ))}
          </div>

          <button 
            onClick={onCancel}
            className="text-red-500 font-semibold hover:text-red-600 transition-colors pt-4 z-20 relative"
          >
            Cancel Search
          </button>
        </div>
      </motion.div>
    </div>
  );
}
