import { APIProvider, Map } from "@vis.gl/react-google-maps";
import { useMemo } from "react";

const API_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || "";
const hasValidKey = Boolean(API_KEY) && API_KEY !== "YOUR_API_KEY";

export default function MapDisplay() {
  const center = useMemo(() => ({ lat: 12.9716, lng: 77.5946 }), []); // Default to Bangalore/India for demo

  return (
    <div className="w-full h-full relative map-grid bg-slate-50 overflow-hidden">
      {/* Decorative Lines */}
      <div className="map-line h-[1px] w-full top-1/4" />
      <div className="map-line h-[1px] w-full top-2/4" />
      <div className="map-line h-[1px] w-full top-3/4" />
      <div className="map-line w-[1px] h-full left-1/4" />
      <div className="map-line w-[1px] h-full left-2/4" />
      <div className="map-line w-[1px] h-full left-3/4" />

      {/* Mock Drivers for Demo */}
      <div className="absolute inset-0 z-1 pointer-events-none opacity-40">
        <div className="mock-driver top-[20%] left-[30%]" />
        <div className="mock-driver top-[45%] left-[60%]" />
        <div className="mock-driver top-[70%] left-[20%]" />
        <div className="mock-driver top-[30%] left-[80%]" />
        <div className="mock-driver top-[60%] left-[50%]" />
      </div>

      {hasValidKey ? (
        <APIProvider apiKey={API_KEY}>
          <div className="w-full h-full relative">
            <Map
              defaultCenter={center}
              defaultZoom={13}
              mapId="SHIFTEASY_MAP"
              disableDefaultUI={true}
              style={{ width: "100%", height: "100%" }}
              internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}
            />
            <div className="absolute inset-0 bg-linear-to-b from-black/5 to-transparent pointer-events-none" />
          </div>
        </APIProvider>
      ) : (
        <div className="flex flex-col items-center justify-center h-full p-6 text-center z-10 relative">
          <div className="bg-white/40 backdrop-blur-md p-8 rounded-[32px] border border-white/40 shadow-xl max-w-sm">
            <h2 className="text-xl font-bold mb-3 text-slate-800">Ready for Mapping</h2>
            <p className="text-slate-500 text-sm mb-6">
              Connect your Google Maps API key to see the live logistics grid.
            </p>
            <div className="flex items-center gap-2 px-4 py-2 bg-slate-900/5 rounded-full text-[10px] font-bold text-slate-400 uppercase tracking-widest mx-auto w-fit">
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
              API Connection Required
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
