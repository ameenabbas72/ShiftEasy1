import { useState } from "react";
import { motion } from "motion/react";
import { 
  Search, MapPin, Truck, Bike, Home, 
  Briefcase, Globe, Zap, Package, 
  Construction, Utensils, FileText, 
  ChevronRight, ArrowRight, Star
} from "lucide-react";
import { cn } from "../lib/utils";

interface CustomerHomeProps {
  onStartBooking: (type?: string) => void;
  userName: string;
}

const SERVICES = [
  { id: "mini", name: "Mini Truck", icon: Truck, color: "bg-blue-500", desc: "For bulky items" },
  { id: "bike", name: "Bike Delivery", icon: Bike, color: "bg-emerald-500", desc: "Small parcels" },
  { id: "house", name: "House Shifting", icon: Home, color: "bg-orange-500", desc: "Full home move" },
  { id: "office", name: "Office Shifting", icon: Briefcase, color: "bg-purple-500", desc: "Commercial moves" },
  { id: "intercity", name: "Intercity", icon: Globe, color: "bg-red-500", desc: "City to city" },
];

const CATEGORIES = [
  { name: "Furniture", icon: Zap },
  { name: "Materials", icon: Construction },
  { name: "Grocery", icon: Utensils },
  { name: "Courier", icon: FileText },
  { name: "Heavy Load", icon: Package },
  { name: "Others", icon: Search },
];

export default function CustomerHome({ onStartBooking, userName }: CustomerHomeProps) {
  return (
    <div className="w-full max-w-2xl mx-auto pb-24 bg-white min-h-screen lg:rounded-[32px] lg:shadow-2xl overflow-hidden">
      {/* Top Section */}
      <div className="bg-blue-600 p-6 pt-12 text-white rounded-b-[40px] shadow-lg">
        <div className="flex items-center justify-between mb-8">
          <div>
            <p className="text-blue-100 text-xs font-bold uppercase tracking-widest mb-1">Welcome back</p>
            <h1 className="text-2xl font-black">{userName}!</h1>
          </div>
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
            <MapPin className="w-6 h-6" />
          </div>
        </div>

        <h2 className="text-3xl font-black mb-8 leading-tight">
          Move Anything, <br />
          <span className="text-blue-200">Anytime.</span>
        </h2>

        <div className="space-y-3">
          <div className="relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-blue-200" />
            <input 
              readOnly
              onClick={() => onStartBooking()}
              placeholder="Search Pickup Location" 
              className="w-full pl-10 pr-4 py-4 bg-white/10 border border-white/20 rounded-2xl text-sm font-bold placeholder:text-blue-100/60 focus:bg-white focus:text-slate-900 transition-all cursor-pointer"
            />
          </div>
          <div className="relative">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 w-2 h-2 rounded-full bg-red-400" />
            <input 
              readOnly
              onClick={() => onStartBooking()}
              placeholder="Search Drop Location" 
              className="w-full pl-10 pr-4 py-4 bg-white/10 border border-white/20 rounded-2xl text-sm font-bold placeholder:text-blue-100/60 focus:bg-white focus:text-slate-900 transition-all cursor-pointer"
            />
          </div>
          <button 
            onClick={() => onStartBooking()}
            className="w-full py-4 bg-white text-blue-600 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-blue-900/20 active:scale-95 transition-all"
          >
            Get Live Estimate
          </button>
        </div>
      </div>

      <div className="p-6 space-y-10">
        {/* Service Cards Slider */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">Our Services</h3>
            <button className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-1">
              View All <ChevronRight className="w-3 h-3" />
            </button>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar -mx-6 px-6">
            {SERVICES.map((s) => {
              const Icon = s.icon;
              return (
                <motion.button 
                  whileTap={{ scale: 0.95 }}
                  key={s.id}
                  onClick={() => onStartBooking(s.id)}
                  className="w-40 shrink-0 bg-slate-50 rounded-[32px] p-5 text-left border-2 border-transparent hover:border-blue-100 hover:bg-white transition-all group"
                >
                  <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110", s.color)}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="font-black text-slate-900 text-sm mb-1">{s.name}</h4>
                  <p className="text-[10px] text-slate-400 font-bold leading-tight">{s.desc}</p>
                </motion.button>
              );
            })}
          </div>
        </section>

        {/* Offer Banner */}
        <div className="relative h-40 bg-gradient-to-r from-orange-500 to-red-600 rounded-[32px] p-8 text-white overflow-hidden shadow-xl shadow-orange-500/20">
          <div className="relative z-10">
            <span className="text-[10px] font-black bg-white/20 px-2 py-1 rounded-md uppercase tracking-widest">Limited Offer</span>
            <h3 className="text-xl font-black mt-2">Get 30% Off on <br />First Shift!</h3>
            <p className="text-[10px] font-bold text-orange-100 mt-2 opacity-80 uppercase tracking-widest">Use code: FIRSTMOVE</p>
          </div>
          <Zap className="absolute -bottom-8 -right-8 w-40 h-40 text-white/10 rotate-12" />
        </div>

        {/* Categories Grid */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">Quick Categories</h3>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {CATEGORIES.map((c) => {
              const Icon = c.icon;
              return (
                <motion.button 
                  whileTap={{ scale: 0.95 }}
                  key={c.name}
                  onClick={() => onStartBooking()}
                  className="flex flex-col items-center gap-3 p-4 bg-white border-2 border-slate-50 rounded-[28px] hover:border-blue-100 hover:shadow-lg transition-all"
                >
                  <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-black text-slate-600 uppercase tracking-tighter">{c.name}</span>
                </motion.button>
              );
            })}
          </div>
        </section>

        {/* Info Banner */}
        <div className="bg-slate-900 p-8 rounded-[32px] text-white flex items-center justify-between">
          <div>
            <h3 className="text-lg font-black mb-1">ShiftEasy Partner</h3>
            <p className="text-xs text-slate-400 font-medium">Join our fleet and start earning today.</p>
          </div>
          <button className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-600/30">
            <ArrowRight className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
}
