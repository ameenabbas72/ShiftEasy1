export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: "customer" | "driver" | "admin";
  phoneNumber?: string;
  createdAt: string;
}

export interface DriverProfile extends UserProfile {
  vehicleId: VehicleType;
  vehicleNumber: string;
  status: "online" | "offline" | "busy";
  rating: number;
  totalTrips: number;
  walletBalance: number;
  currentLat?: number;
  currentLng?: number;
  kycStatus: "pending" | "verified" | "rejected";
}

export interface ItemDetails {
  itemName: string;
  category: string;
  weight: number;
  quantity: number;
  fragile: boolean;
  specialInstructions: string;
  itemPhoto?: string;
}

export interface Booking {
  bookingID: string;
  userId: string;
  pickup: {
    address: string;
    lat: number;
    lng: number;
  };
  drop: {
    address: string;
    lat: number;
    lng: number;
  };
  distance: number;
  vehicleType: VehicleType;
  itemDetails: ItemDetails;
  totalFare: number;
  fareBreakdown: {
    baseFare: number;
    distanceFare: number;
    vehicleFareExtra: number;
    weightCharge: number;
    waitingCharge: number;
    nightCharge: number;
    gst: number;
  };
  paymentMethod: "cash" | "upi" | "card" | "wallet";
  paymentStatus: "pending" | "paid";
  timestamp: string;
  status: "searching" | "confirmed" | "picked_up" | "on_route" | "delivered" | "cancelled";
  driverId?: string;
}

export type VehicleType = "bike" | "auto" | "tata_ace" | "mini_tempo" | "big_tempo" | "truck";

export interface Vehicle {
  id: VehicleType;
  name: string;
  capacity: number; // in KG
  baseFare: number;
  perKm: number;
  description: string;
  icon: string;
}

export const VEHICLES: Vehicle[] = [
  {
    id: "bike",
    name: "Bike",
    capacity: 20,
    baseFare: 40,
    perKm: 8,
    description: "Small parcels & documents.",
    icon: "Bike",
  },
  {
    id: "auto",
    name: "Auto",
    capacity: 250,
    baseFare: 150,
    perKm: 15,
    description: "Small items, boxes & groceries.",
    icon: "Package",
  },
  {
    id: "tata_ace",
    name: "Tata Ace (Chota Hathi)",
    capacity: 750,
    baseFare: 450,
    perKm: 25,
    description: "Furniture, fridge & small shifting.",
    icon: "Truck",
  },
  {
    id: "mini_tempo",
    name: "Mini Tempo (8ft)",
    capacity: 1200,
    baseFare: 750,
    perKm: 35,
    description: "Large items, 1BHK partial move.",
    icon: "Truck",
  },
  {
    id: "big_tempo",
    name: "Big Tempo (14ft)",
    capacity: 2500,
    baseFare: 1200,
    perKm: 50,
    description: "Full 1BHK/2BHK shifting.",
    icon: "Truck",
  },
  {
    id: "truck",
    name: "Truck",
    capacity: 5000,
    baseFare: 2500,
    perKm: 80,
    description: "Full home shifting (3BHK+).",
    icon: "Ship",
  },
];
