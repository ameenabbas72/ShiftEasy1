import { useState, useEffect } from "react";
import MapDisplay from "./components/MapDisplay";
import SearchingOverlay from "./components/SearchingOverlay";
import BookingConfirmation from "./components/BookingConfirmation";
import NavigationPanels from "./components/NavigationPanels";
import AuthScreen from "./components/AuthScreen";
import OnlinePaymentGateway from "./components/OnlinePaymentGateway";
import CustomerHome from "./components/CustomerHome";
import DriverHome from "./components/DriverHome";
import FloatingForm from "./components/FloatingForm";
import { onAuthStateChanged } from "firebase/auth";
import { auth, db } from "./lib/firebase";
import { Booking, VehicleType, UserProfile } from "./types";
import { collection, addDoc, doc, setDoc, query, where, onSnapshot, getDocs, getDoc, serverTimestamp } from "firebase/firestore";
import { cn } from "./lib/utils";
import { AnimatePresence } from "motion/react";
import { handleFirestoreError, OperationType } from "./lib/firestore-errors";

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [activeRole, setActiveRole] = useState<"customer" | "driver">("customer");
  
  const [isSearching, setIsSearching] = useState(false);
  const [currentSearchVehicle, setCurrentSearchVehicle] = useState<VehicleType | null>(null);
  const [bookingDetails, setBookingDetails] = useState<Booking | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  
  const [showNav, setShowNav] = useState(false);
  const [activePanel, setActivePanel] = useState<"profile" | "history" | "help" | "services" | "bookings" | "support">("profile");
  
  const [showPaymentGateway, setShowPaymentGateway] = useState(false);
  const [pendingBookingData, setPendingBookingData] = useState<any>(null);
  
  const [isBookingFlow, setIsBookingFlow] = useState(false);
  const [driverOnline, setDriverOnline] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        try {
          // Fetch or Create Profile
          const userDocRef = doc(db, "users", u.uid);
          const snap = await getDoc(userDocRef);
          
          if (snap.exists()) {
            const profile = snap.data() as UserProfile;
            setUserProfile(profile);
            if (profile.role === "driver") setActiveRole("driver");
          } else {
            // Create new profile if it doesn't exist
            const newProfile: UserProfile = {
              uid: u.uid,
              email: u.email || "",
              displayName: u.displayName || "New User",
              role: "customer",
              createdAt: new Date().toISOString()
            };
            await setDoc(userDocRef, newProfile);
            setUserProfile(newProfile);
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${u.uid}`);
        }
      } else {
        setUserProfile(null);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleBook = async (data: Partial<Booking>) => {
    if (!user) return;
    
    if (data.paymentMethod === "upi" || data.paymentMethod === "card") {
      setPendingBookingData(data);
      setShowPaymentGateway(true);
      return;
    }

    processBooking(data);
  };

  const processBooking = async (data: Partial<Booking>) => {
    setIsSearching(true);
    setCurrentSearchVehicle(data.vehicleType!);
    let bookingID = "";

    try {
      bookingID = `SH-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      const finalData: Booking = {
        ...data as any,
        bookingID,
        userId: user!.uid,
        status: "confirmed",
        paymentStatus: (data.paymentMethod === "upi" || data.paymentMethod === "card") ? "paid" : "pending",
        timestamp: new Date().toISOString()
      };

      await setDoc(doc(db, "bookings", bookingID), {
        ...finalData,
        createdAt: serverTimestamp()
      });
      
      // Simulate finding a driver
      setTimeout(() => {
        setIsSearching(false);
        setBookingDetails(finalData);
        setShowConfirmation(true);
        setIsBookingFlow(false);
      }, 3000);

    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `bookings/${bookingID}`);
      setIsSearching(false);
    }
  };

  const handlePaymentSuccess = () => {
    setShowPaymentGateway(false);
    if (pendingBookingData) {
      processBooking(pendingBookingData);
      setPendingBookingData(null);
    }
  };

  if (!user) {
    return <AuthScreen onAuthComplete={(u) => setUser(u)} />;
  }

  return (
    <div className="relative w-full h-screen overflow-hidden bg-slate-50 font-sans">
      {/* Role Switcher - Demo Helper (Hidden in Production) */}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[60] bg-slate-900 border border-white/10 shadow-2xl rounded-full p-1 flex gap-1 opacity-40 hover:opacity-100 transition-opacity">
        <button 
          onClick={() => setActiveRole("customer")}
          className={cn(
            "px-4 py-1 text-[8px] font-black uppercase tracking-widest rounded-full transition-all",
            activeRole === "customer" ? "bg-white text-slate-900" : "text-white/60 hover:text-white"
          )}
        >
          Customer UI
        </button>
        <button 
          onClick={() => setActiveRole("driver")}
          className={cn(
            "px-4 py-1 text-[8px] font-black uppercase tracking-widest rounded-full transition-all",
            activeRole === "driver" ? "bg-white text-slate-900" : "text-white/60 hover:text-white"
          )}
        >
          Driver UI
        </button>
      </div>

      <main className="relative w-full h-full flex flex-col items-center justify-center">
        {activeRole === "customer" ? (
          <div className="w-full h-full relative flex flex-col">
            {/* Background Map (Lower Opacity when Home is active) */}
            <div className={cn("absolute inset-0 z-0 transition-opacity duration-1000", isBookingFlow ? "opacity-100" : "opacity-30")}>
              <MapDisplay />
            </div>

            {/* Front UI Layer */}
            <div className="relative z-10 w-full h-full overflow-y-auto custom-scrollbar no-scrollbar lg:flex lg:items-center lg:justify-center p-0 lg:p-12">
              {!isBookingFlow ? (
                <CustomerHome 
                  userName={user?.displayName?.split(" ")[0] || "User"} 
                  onStartBooking={() => setIsBookingFlow(true)} 
                />
              ) : (
                <div className="w-full h-full flex flex-col p-6 pointer-events-none">
                   <FloatingForm onBook={handleBook} />
                   <button 
                    onClick={() => setIsBookingFlow(false)}
                    className="fixed top-6 left-6 z-50 p-4 bg-white rounded-2xl shadow-xl pointer-events-auto active:scale-95 transition-all text-slate-400 hover:text-blue-600"
                   >
                    <HomeIcon className="w-6 h-6" />
                   </button>
                </div>
              )}
            </div>
            
            {/* Profile Action */}
            <div className="fixed top-6 right-6 z-30 flex flex-col gap-3">
              <button 
                onClick={() => { setActivePanel("profile"); setShowNav(true); }}
                className="w-12 h-12 bg-white rounded-2xl shadow-xl flex items-center justify-center text-slate-400 hover:text-blue-600 transition-all active:scale-95"
              >
                {user.photoURL ? (
                  <img src={user.photoURL} className="w-8 h-8 rounded-xl object-cover" />
                ) : (
                  <div className="w-8 h-8 rounded-xl bg-slate-100" />
                )}
              </button>
            </div>
          </div>
        ) : (
          <div className="w-full h-full">
            <DriverHome 
              isOnline={driverOnline}
              onStatusToggle={setDriverOnline}
              activeBooking={bookingDetails && bookingDetails.status !== "delivered" ? bookingDetails : undefined}
              onAcceptOrder={() => {}}
              onRejectOrder={() => {}}
              onUpdateStatus={(status) => setBookingDetails(prev => prev ? { ...prev, status } : null)}
            />
          </div>
        )}

        <AnimatePresence>
          {isSearching && currentSearchVehicle && (
            <SearchingOverlay 
              vehicleType={currentSearchVehicle} 
              onCancel={() => setIsSearching(false)} 
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showConfirmation && bookingDetails && ( activeRole === "customer" ) && (
            <BookingConfirmation 
              booking={bookingDetails} 
              onClose={() => setShowConfirmation(false)} 
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showNav && (
            <NavigationPanels 
              activePanel={activePanel} 
              onClose={() => setShowNav(false)} 
              onSwitchPanel={setActivePanel as any}
            />
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showPaymentGateway && (
            <OnlinePaymentGateway 
              amount={pendingBookingData?.totalFare || 0}
              onSuccess={handlePaymentSuccess}
              onCancel={() => setShowPaymentGateway(false)}
            />
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

function HomeIcon(props: any) {
  return (
    <svg {...props} width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  );
}
