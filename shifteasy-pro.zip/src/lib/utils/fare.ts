import { Vehicle } from "../../types";

export interface FareBreakdown {
  baseFare: number;
  distanceFare: number;
  vehicleFareExtra: number;
  weightCharge: number;
  waitingCharge: number;
  nightCharge: number;
  gst: number;
  total: number;
}

export function calculateDetailedFare(
  distance: number,
  vehicle: Vehicle,
  weight: number = 0,
  isNight: boolean = false
): FareBreakdown {
  // Distance Slab Logic
  let distanceFare = 0;
  const dist = Math.max(0, distance);

  if (dist > 3) {
    const slab1 = Math.min(dist - 3, 7); // 3 to 10 km
    distanceFare += slab1 * 12;

    if (dist > 10) {
      const slab2 = Math.min(dist - 10, 15); // 10 to 25 km
      distanceFare += slab2 * 10;

      if (dist > 25) {
        const slab3 = Math.min(dist - 25, 25); // 25 to 50 km
        distanceFare += slab3 * 8;

        if (dist > 50) {
          const slab4 = dist - 50; // 50+ km
          distanceFare += slab4 * 7;
        }
      }
    }
  }

  // Scaling distance fare by vehicle type factor (relative to 'auto' which is 1.0)
  // Standardizing 'auto' as the 1.0 factor
  const vehicleFactor = vehicle.id === 'bike' ? 0.6 
    : vehicle.id === 'auto' ? 1.0 
    : vehicle.id === 'tata_ace' ? 1.8 
    : vehicle.id === 'mini_tempo' ? 2.5 
    : vehicle.id === 'big_tempo' ? 4.0 
    : 8.0;

  const adjustedDistanceFare = Math.round(distanceFare * vehicleFactor);
  const baseFare = vehicle.baseFare;

  // Extra charges
  const weightCharge = weight > vehicle.capacity ? (weight - vehicle.capacity) * 2 : 0;
  const waitingCharge = 0; // Placeholder
  const nightCharge = isNight ? Math.round(baseFare * 0.25) : 0;
  
  const subtotal = baseFare + adjustedDistanceFare + weightCharge + waitingCharge + nightCharge;
  const gst = Math.round(subtotal * 0.18);
  const total = subtotal + gst;

  return {
    baseFare,
    distanceFare: adjustedDistanceFare,
    vehicleFareExtra: 0, // already folded into dist fare
    weightCharge,
    waitingCharge,
    nightCharge,
    gst,
    total: Math.round(total),
  };
}
